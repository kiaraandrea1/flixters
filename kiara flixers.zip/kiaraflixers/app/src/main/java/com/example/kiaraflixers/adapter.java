package com.example.kiaraflixers;


import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.TextView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<Adapter.MyViewHolder> {
    private Context mContext;
    private List<moviemodel> mData;
    public Adapter(Context mContext, List<moviemodel>mData){
        this.mContext =mContext;
        this.mData =mData;
    }



   @NonNull
   @Override
   public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
       View v;
       LayoutInflater inflater = LayoutInflater.from(mContext);
               v = inflater.inflate(R.layout.movie_item,parent,false);
       return new MyViewHolder(v);
   }
   @Override
   public void onBindViewHolder(@NonNull MyViewHolder holder, int position){

        holder.id.setText(mData.get(position).getId());
        holder.name.setText(mData.get(position).getName());

        //Using Glide library to display the image
       Glide.with(mContext)
               .load(mData)
               .intro(holder.img);
   }
   @Override
   public int getItemCount(){
        return 0;
   }




    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView id;
        TextView name;
        TextView img;

        public MyViewHolder(@NonNull View itemViem){
            super(itemViem);

            id = itemViem.findViewById(R.id.nametxt);
            name = itemViem.findViewById(R.id.textView);
            img = itemViem.findViewById(R.id.imageView);
        }

    }
}
